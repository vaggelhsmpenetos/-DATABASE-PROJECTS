-- 3.1.3.1

CALL InsertDriver(
	'ΑΑ511115',
	'ΣΤΑΥΡΟΣ',
	'ΑΝΤΩΝΙΟΥ',
	1040.50,
	'C',
	'LOCAL',
	34);

-- 3.1.3.2
CALL GetTripData(
	104,
	'2022-12-20',
	'2023-01-01'
);

-- 3.1.3.3
-- Απόπειρα διαγραφής manager
CALL DeleteAdmin (
	'ΑΝΤΙΓΟΝΗ',
	'ΓΙΑΚΟΥΜΗ'
);

-- Απόπειρα διαγραφής διοικητικού
CALL DeleteAdmin (
	'ΣΑΜΟΥΗΛ',
	'ΠΑΝΤΑΖΗΣ'
);

-- 3.1.3.4α
CALL GetReservationsWithDownpayment (
	50, 100
)

-- 3.1.3.4β
CALL GetReservationsPerLastname (
	'Flatley'
)

-- TRIGGERS
-- 3.1.4.1.
-- Πίνακας trip
INSERT INTO trip (tr_id, tr_departure, tr_return, tr_maxseats, tr_cost, tr_br_code, tr_gui_AT, tr_drv_AT) VALUES ('23', '2023-01-31', '2023-02-08', '34', '530', '116', 'ΑΒ233851', 'ΑΖ803910');

SELECT * FROM log;

UPDATE trip 
SET tr_br_code='104'
WHERE tr_id=23;

SELECT * FROM log;

DELETE FROM trip
WHERE tr_id=23;

SELECT * FROM log;

-- Πίνακας reservation
INSERT INTO reservation (res_tr_id, res_seatnum, res_name, res_lname, res_isadult) 
VALUES ('1000', '14', 'ΕΥΑΓΓΕΛΟΣ', 'ΚΟΥΤΣΟΦ', 'ADULT');

SELECT * FROM log;

UPDATE reservation 
SET res_seatnum=15
WHERE res_tr_id=1000;

SELECT * FROM log;

DELETE FROM reservation
WHERE res_lname='ΚΟΥΤΣΟΦ';

SELECT * FROM log;

-- Πίνακας event
INSERT INTO `event` (ev_tr_id, ev_start, ev_end, ev_descr) 
VALUES ('1000', '2023-01-21', '2023-01-21', 'ΟΡΕΙΒΑΣΙΑ');

SELECT * FROM log;

UPDATE `event`
SET ev_start='2023-01-20'
WHERE ev_tr_id=1000 AND ev_descr='ΟΡΕΙΒΑΣΙΑ';

SELECT * FROM log;

DELETE 
FROM `event`
WHERE ev_tr_id=1000 AND ev_descr='ΟΡΕΙΒΑΣΙΑ';

SELECT * FROM log;

-- 3.1.4.3.
-- To ταξίδι με tr_id=1 έχει κρατήσεις
SELECT * FROM trip WHERE tr_id=1;

UPDATE trip
SET tr_departure='2023-01-10'
WHERE tr_id=1;

SELECT * FROM trip WHERE tr_id=1;

SELECT * FROM trip WHERE tr_id=1;

UPDATE trip
SET tr_return='2023-01-10'
WHERE tr_id=1;

SELECT * FROM trip WHERE tr_id=1;

SELECT * FROM trip WHERE tr_id=1;

UPDATE trip
SET tr_cost=1900
WHERE tr_id=1;

SELECT * FROM trip WHERE tr_id=1;

-- Το ταξίδι με tr_id=19 δεν έχει κρατήσεις
SELECT * FROM trip WHERE tr_id=19;

UPDATE trip
SET tr_departure='2023-01-10'
WHERE tr_id=19;

SELECT * FROM trip WHERE tr_id=19;

SELECT * FROM trip WHERE tr_id=19;

UPDATE trip
SET tr_return='2023-01-10'
WHERE tr_id=19;

SELECT * FROM trip WHERE tr_id=19;

SELECT * FROM trip WHERE tr_id=19;

UPDATE trip
SET tr_cost=1900
WHERE tr_id=19;

SELECT * FROM trip WHERE tr_id=19;

-- 3.1.4.3
SELECT * FROM worker WHERE wrk_AT='ΑΑ511297';

UPDATE worker
SET wrk_salary=1200.00
WHERE wrk_AT='ΑΑ511297';

SELECT * FROM worker WHERE wrk_AT='ΑΑ511297';

