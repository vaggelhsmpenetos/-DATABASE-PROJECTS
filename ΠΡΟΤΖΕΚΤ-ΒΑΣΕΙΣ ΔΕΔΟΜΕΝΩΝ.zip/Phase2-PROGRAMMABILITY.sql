-- Phase 2 - 3.1.3.1
DROP PROCEDURE IF EXISTS InsertDriver;

DELIMITER $$
CREATE PROCEDURE InsertDriver(
	IN wrk_AT VARCHAR(10),
	IN wrk_name VARCHAR(20),
	IN wrk_lname VARCHAR(20),
	IN wrk_salary FLOAT(7,2),
	IN drv_license CHAR(1),
	IN drv_route VARCHAR(6),
	IN drv_experience TINYINT
)
BEGIN
	DECLARE branch_code INT;
	
	SELECT wrk_br_code INTO branch_code
	FROM worker INNER JOIN driver ON worker.wrk_AT=driver.drv_AT
	GROUP BY wrk_br_code
	ORDER BY COUNT(wrk_AT) ASC
	LIMIT 1;
	
	INSERT INTO worker(wrk_AT, wrk_name, wrk_lname, wrk_salary, wrk_br_code) 
	VALUES (wrk_AT, wrk_name, wrk_lname, wrk_salary, branch_code);

	INSERT INTO driver (drv_AT, drv_license, drv_route, drv_experience) 
	VALUES (wrk_AT, drv_license, drv_route, drv_experience);
END$$
DELIMITER ;

-- 3.1.3.2 
DROP PROCEDURE IF EXISTS GetTripData;

DELIMITER $$
CREATE PROCEDURE GetTripData(
	IN branch_code INT,
	IN date_from DATE,
	IN date_to DATE
)
BEGIN
	SELECT 	trip.tr_cost AS 'Κόστος', 
			trip.tr_maxseats AS 'Σύνολο θέσεων',  
			CONCAT(d.wrk_name, ' ', d.wrk_lname) AS 'Οδηγός',
			CONCAT(g.wrk_name, ' ', g.wrk_lname) AS 'Ξεναγός',
			trip.tr_departure AS 'Αναχώρηση', trip.tr_return AS 'Επιστροφή',
			COUNT(reservation.res_tr_id) AS 'Κρατήσεις', 
			trip.tr_maxseats-COUNT(reservation.res_tr_id) AS 'Κενές θέσεις'
	FROM 	trip INNER JOIN
			reservation ON reservation.res_tr_id=trip.tr_id INNER JOIN
			worker d ON trip.tr_drv_AT=d.wrk_AT INNER JOIN
			worker g ON trip.tr_gui_AT=g.wrk_AT
	WHERE 	tr_br_code=branch_code AND trip.tr_departure BETWEEN date_from AND date_to
	GROUP BY
			trip.tr_cost, 
			trip.tr_maxseats,  
			d.wrk_name, d.wrk_lname,
			g.wrk_name, g.wrk_lname,
			trip.tr_departure, trip.tr_return;
END$$		
DELIMITER ;

-- 3.1.3.3 
DROP PROCEDURE IF EXISTS DeleteAdmin;

DELIMITER $$
CREATE PROCEDURE DeleteAdmin (
	IN wrk_name VARCHAR(20),
	IN wrk_lname VARCHAR(20)
)
BEGIN
    DECLARE admin_AT VARCHAR(10);
    DECLARE manager_AT VARCHAR(10);

	SELECT 	DISTINCT manages.mng_adm_AT INTO manager_AT
	FROM 	manages INNER JOIN worker ON manages.mng_adm_AT=worker.wrk_AT
	WHERE 	worker.wrk_name=wrk_name AND worker.wrk_lname=wrk_lname;	

    if manager_AT IS NOT NULL THEN
    	SELECT 'EINAI ΔΙΕΥΘΥΝΤΗΣ ΚΑΙ ΔΕ ΜΠΟΡΕΙ ΝΑ ΔΙΑΓΡΑΦΕΙ' AS Resut;
	ELSE
		SELECT 	admin.adm_AT INTO admin_AT			
		FROM worker INNER JOIN admin ON worker.wrk_AT=admin.adm_AT
		WHERE worker.wrk_name=wrk_name AND worker.wrk_lname=wrk_lname AND admin.adm_type='ADMINISTRATIVE';

		IF admin_AT IS NOT NULL THEN
			DELETE FROM worker WHERE worker.wrk_AT=admin_AT;
		END IF;
	END IF;
END$$
DELIMITER ;

-- 3.1.3.4α
DROP PROCEDURE IF EXISTS GetReservationsWithDownpayment;

DELIMITER $$
CREATE PROCEDURE GetReservationsWithDownpayment (
	IN amount_from DECIMAL,
	IN amount_to DECIMAL
)
BEGIN
	SELECT reservation_offers.lastname, reservation_offers.firstname
    FROM reservation_offers INNER JOIN offers ON reservation_offers.offer_code=offers.code
    WHERE reservation_offers.amount BETWEEN amount_from AND amount_to;
END$$
DELIMITER ;

-- 3.1.3.4β
DROP PROCEDURE IF EXISTS GetReservationsPerLastname;

DELIMITER $$
CREATE PROCEDURE GetReservationsPerLastname (
	IN cust_name VARCHAR(20)
)
BEGIN
	SELECT 	reservation_offers.lastname, 
    		reservation_offers.firstname,
    		COUNT(reservation_offers.lastname)
    FROM 	reservation_offers 
    WHERE 	reservation_offers.lastname=cust_name
    GROUP BY reservation_offers.lastname, 
    		reservation_offers.firstname;
END$$
DELIMITER ;

-- 3.1.4.1
-- Trigger: ενημερώνει τον πίνακα "log" μετά από μία εισαγωγή στον πίνακα trip
DROP TRIGGER IF EXISTS log_trip_insert;

DELIMITER $$
CREATE TRIGGER log_trip_insert 
AFTER INSERT ON trip FOR EACH ROW
BEGIN
	DECLARE logged_table VARCHAR(20);
	DECLARE logged_action VARCHAR(20);
	DECLARE logged_user VARCHAR(20);
	
    SET logged_table = 'trip';
	SET logged_action = 'INSERT';

	SELECT CONCAT(worker.wrk_name, ' ', worker.wrk_lname) INTO logged_user
	FROM it INNER JOIN worker ON it.it_at=worker.wrk_at
	WHERE it.it_logged = true;	
	
    INSERT INTO `log` (l_table, l_action, l_user)
	VALUES (logged_table, logged_action, logged_user);    
END$$;
DELIMITER ;

-- Trigger: ενημερώνει τον πίνακα "log" μετά από μία ενημέρωση στον πίνακα trip
DROP TRIGGER IF EXISTS log_trip_update;

DELIMITER $$
CREATE TRIGGER log_trip_update
AFTER UPDATE ON trip FOR EACH ROW
BEGIN
	DECLARE logged_table VARCHAR(20);
	DECLARE logged_action VARCHAR(20);
	DECLARE logged_user VARCHAR(20);
	
    SET logged_table = 'trip';
	SET logged_action = 'UPDATE';

	SELECT CONCAT(worker.wrk_name, ' ', worker.wrk_lname) INTO logged_user
	FROM it INNER JOIN worker ON it.it_at=worker.wrk_at
	WHERE it.it_logged = true;	
	
    INSERT INTO `log` (l_table, l_action, l_user)
	VALUES (logged_table, logged_action, logged_user);    
END$$;
DELIMITER ;

-- Trigger: ενημερώνει τον πίνακα "log" μετά από μία διαγραφή στον πίνακα trip
DROP TRIGGER IF EXISTS log_trip_delete;

DELIMITER $$
CREATE TRIGGER log_trip_delete
AFTER DELETE ON trip FOR EACH ROW
BEGIN
	DECLARE logged_table VARCHAR(20);
	DECLARE logged_action VARCHAR(20);
	DECLARE logged_user VARCHAR(20);
	
    SET logged_table = 'trip';
	SET logged_action = 'DELETE';

	SELECT CONCAT(worker.wrk_name, ' ', worker.wrk_lname) INTO logged_user
	FROM it INNER JOIN worker ON it.it_at=worker.wrk_at
	WHERE it.it_logged = true;	
	
    INSERT INTO `log` (l_table, l_action, l_user)
	VALUES (logged_table, logged_action, logged_user);    
END$$;
DELIMITER ;

-- Trigger: ενημερώνει τον πίνακα "log" μετά από μία εισαγωγή στον πίνακα "reservation"
DROP TRIGGER IF EXISTS log_reservation_insert;

DELIMITER $$
CREATE TRIGGER log_reservation_insert 
AFTER INSERT ON reservation FOR EACH ROW
BEGIN
	DECLARE logged_table VARCHAR(20);
	DECLARE logged_action VARCHAR(20);
	DECLARE logged_user VARCHAR(20);
	
    SET logged_table = 'reservation';
	SET logged_action = 'INSERT';

	SELECT CONCAT(worker.wrk_name, ' ', worker.wrk_lname) INTO logged_user
	FROM it INNER JOIN worker ON it.it_at=worker.wrk_at
	WHERE it.it_logged = true;	
	
    INSERT INTO `log` (l_table, l_action, l_user)
	VALUES (logged_table, logged_action, logged_user);    
END$$;
DELIMITER ;

-- Trigger: ενημερώνει τον πίνακα "log" μετά από μία ενημέρωση στον πίνακα "reservation"
DROP TRIGGER IF EXISTS log_reservation_update;

DELIMITER $$
CREATE TRIGGER log_reservation_update
AFTER UPDATE ON reservation FOR EACH ROW
BEGIN
	DECLARE logged_table VARCHAR(20);
	DECLARE logged_action VARCHAR(20);
	DECLARE logged_user VARCHAR(20);
	
    SET logged_table = 'reservation';
	SET logged_action = 'UPDATE';

	SELECT CONCAT(worker.wrk_name, ' ', worker.wrk_lname) INTO logged_user
	FROM it INNER JOIN worker ON it.it_at=worker.wrk_at
	WHERE it.it_logged = true;	
	
    INSERT INTO `log` (l_table, l_action, l_user)
	VALUES (logged_table, logged_action, logged_user);    
END$$;
DELIMITER ;

-- Trigger: ενημερώνει τον πίνακα "log" μετά από μία διαγραφή στον πίνακα "reservation"
DROP TRIGGER IF EXISTS log_reservation_delete;

DELIMITER $$
CREATE TRIGGER log_reservation_delete
AFTER DELETE ON reservation FOR EACH ROW
BEGIN
	DECLARE logged_table VARCHAR(20);
	DECLARE logged_action VARCHAR(20);
	DECLARE logged_user VARCHAR(20);
	
    SET logged_table = 'reservation';
	SET logged_action = 'DELETE';

	SELECT CONCAT(worker.wrk_name, ' ', worker.wrk_lname) INTO logged_user
	FROM it INNER JOIN worker ON it.it_at=worker.wrk_at
	WHERE it.it_logged = true;	
	
    INSERT INTO `log` (l_table, l_action, l_user)
	VALUES (logged_table, logged_action, logged_user);    
END$$;
DELIMITER ;


-- Trigger: ενημερώνει τον πίνακα "log" μετά από μία εισαγωγή στον πίνακα "event"
DROP TRIGGER IF EXISTS log_event_insert;

DELIMITER $$
CREATE TRIGGER log_event_insert 
AFTER INSERT ON event FOR EACH ROW
BEGIN
	DECLARE logged_table VARCHAR(20);
	DECLARE logged_action VARCHAR(20);
	DECLARE logged_user VARCHAR(20);
	
    SET logged_table = 'event';
	SET logged_action = 'INSERT';

	SELECT CONCAT(worker.wrk_name, ' ', worker.wrk_lname) INTO logged_user
	FROM it INNER JOIN worker ON it.it_at=worker.wrk_at
	WHERE it.it_logged = true;	
	
    INSERT INTO `log` (l_table, l_action, l_user)
	VALUES (logged_table, logged_action, logged_user);    
END$$;
DELIMITER ;

-- Trigger: ενημερώνει τον πίνακα "log" μετά από μία ενημέρωση στον πίνακα "event"
DROP TRIGGER IF EXISTS log_event_update;

DELIMITER $$
CREATE TRIGGER log_event_update
AFTER UPDATE ON event FOR EACH ROW
BEGIN
	DECLARE logged_table VARCHAR(20);
	DECLARE logged_action VARCHAR(20);
	DECLARE logged_user VARCHAR(20);
	
    SET logged_table = 'event';
	SET logged_action = 'UPDATE';

	SELECT CONCAT(worker.wrk_name, ' ', worker.wrk_lname) INTO logged_user
	FROM it INNER JOIN worker ON it.it_at=worker.wrk_at
	WHERE it.it_logged = true;	
	
    INSERT INTO `log` (l_table, l_action, l_user)
	VALUES (logged_table, logged_action, logged_user);    
END$$;
DELIMITER ;

-- Trigger: ενημερώνει τον πίνακα "log" μετά από μία διαγραφή στον πίνακα "event"
DROP TRIGGER IF EXISTS log_event_delete;

DELIMITER $$
CREATE TRIGGER log_event_delete
AFTER DELETE ON event FOR EACH ROW
BEGIN
	DECLARE logged_table VARCHAR(20);
	DECLARE logged_action VARCHAR(20);
	DECLARE logged_user VARCHAR(20);
	
    SET logged_table = 'event';
	SET logged_action = 'DELETE';

	SELECT CONCAT(worker.wrk_name, ' ', worker.wrk_lname) INTO logged_user
	FROM it INNER JOIN worker ON it.it_at=worker.wrk_at
	WHERE it.it_logged = true;	
	
    INSERT INTO `log` (l_table, l_action, l_user)
	VALUES (logged_table, logged_action, logged_user);    
END$$;
DELIMITER ;


-- Trigger: ενημερώνει τον πίνακα "log" μετά από μία εισαγωγή στον πίνακα "travel_to"
DROP TRIGGER IF EXISTS log_travel_to_insert;

DELIMITER $$
CREATE TRIGGER log_travel_to_insert 
AFTER INSERT ON travel_to FOR EACH ROW
BEGIN
	DECLARE logged_table VARCHAR(20);
	DECLARE logged_action VARCHAR(20);
	DECLARE logged_user VARCHAR(20);
	
    SET logged_table = 'travel_to';
	SET logged_action = 'INSERT';

	SELECT CONCAT(worker.wrk_name, ' ', worker.wrk_lname) INTO logged_user
	FROM it INNER JOIN worker ON it.it_at=worker.wrk_at
	WHERE it.it_logged = true;	
	
    INSERT INTO `log` (l_table, l_action, l_user)
	VALUES (logged_table, logged_action, logged_user);    
END$$;
DELIMITER ;

-- Trigger: ενημερώνει τον πίνακα "log" μετά από μία ενημέρωση στον πίνακα "travel_to"
DROP TRIGGER IF EXISTS log_travel_to_update;

DELIMITER $$
CREATE TRIGGER log_travel_to_update
AFTER UPDATE ON travel_to FOR EACH ROW
BEGIN
	DECLARE logged_table VARCHAR(20);
	DECLARE logged_action VARCHAR(20);
	DECLARE logged_user VARCHAR(20);
	
    SET logged_table = 'travel_to';
	SET logged_action = 'UPDATE';

	SELECT CONCAT(worker.wrk_name, ' ', worker.wrk_lname) INTO logged_user
	FROM it INNER JOIN worker ON it.it_at=worker.wrk_at
	WHERE it.it_logged = true;	
	
    INSERT INTO `log` (l_table, l_action, l_user)
	VALUES (logged_table, logged_action, logged_user);    
END$$;
DELIMITER ;

-- Trigger: ενημερώνει τον πίνακα "log" μετά από μία διαγραφή στον πίνακα "travel_to"
DROP TRIGGER IF EXISTS log_travel_to_delete;

DELIMITER $$
CREATE TRIGGER log_travel_to_delete
AFTER DELETE ON travel_to FOR EACH ROW
BEGIN
	DECLARE logged_table VARCHAR(20);
	DECLARE logged_action VARCHAR(20);
	DECLARE logged_user VARCHAR(20);
	
    SET logged_table = 'travel_to';
	SET logged_action = 'DELETE';

	SELECT CONCAT(worker.wrk_name, ' ', worker.wrk_lname) INTO logged_user
	FROM it INNER JOIN worker ON it.it_at=worker.wrk_at
	WHERE it.it_logged = true;	
	
    INSERT INTO `log` (l_table, l_action, l_user)
	VALUES (logged_table, logged_action, logged_user);    
END$$;
DELIMITER ;


-- Trigger: ενημερώνει τον πίνακα "log" μετά από μία εισαγωγή στον πίνακα "destination"
DROP TRIGGER IF EXISTS log_destination_insert;

DELIMITER $$
CREATE TRIGGER log_destination_insert 
AFTER INSERT ON destination FOR EACH ROW
BEGIN
	DECLARE logged_table VARCHAR(20);
	DECLARE logged_action VARCHAR(20);
	DECLARE logged_user VARCHAR(20);
	
    SET logged_table = 'destination';
	SET logged_action = 'INSERT';

	SELECT CONCAT(worker.wrk_name, ' ', worker.wrk_lname) INTO logged_user
	FROM it INNER JOIN worker ON it.it_at=worker.wrk_at
	WHERE it.it_logged = true;	
	
    INSERT INTO `log` (l_table, l_action, l_user)
	VALUES (logged_table, logged_action, logged_user);    
END$$;
DELIMITER ;

-- Trigger: ενημερώνει τον πίνακα "log" μετά από μία ενημέρωση στον πίνακα "destination"
DROP TRIGGER IF EXISTS log_destination_update;

DELIMITER $$
CREATE TRIGGER log_destination_update
AFTER UPDATE ON destination FOR EACH ROW
BEGIN
	DECLARE logged_table VARCHAR(20);
	DECLARE logged_action VARCHAR(20);
	DECLARE logged_user VARCHAR(20);
	
    SET logged_table = 'destination';
	SET logged_action = 'UPDATE';

	SELECT CONCAT(worker.wrk_name, ' ', worker.wrk_lname) INTO logged_user
	FROM it INNER JOIN worker ON it.it_at=worker.wrk_at
	WHERE it.it_logged = true;	
	
    INSERT INTO `log` (l_table, l_action, l_user)
	VALUES (logged_table, logged_action, logged_user);    
END$$;
DELIMITER ;

-- Trigger: ενημερώνει τον πίνακα "log" μετά από μία διαγραφή στον πίνακα "destination"
DROP TRIGGER IF EXISTS log_destination_delete;

DELIMITER $$
CREATE TRIGGER log_destination_delete
AFTER DELETE ON destination FOR EACH ROW
BEGIN
	DECLARE logged_table VARCHAR(20);
	DECLARE logged_action VARCHAR(20);
	DECLARE logged_user VARCHAR(20);
	
    SET logged_table = 'destination';
	SET logged_action = 'DELETE';

	SELECT CONCAT(worker.wrk_name, ' ', worker.wrk_lname) INTO logged_user
	FROM it INNER JOIN worker ON it.it_at=worker.wrk_at
	WHERE it.it_logged = true;	
	
    INSERT INTO `log` (l_table, l_action, l_user)
	VALUES (logged_table, logged_action, logged_user);    
END$$;
DELIMITER ;


-- 3.1.4.2
-- Trigger: prevent_trip_update
-- Αποτρέπει την αλλαγή 
-- της ημερομηνίας αναχώρησης, 
-- της ημερομηνίας επιστροφής και 
-- του κόστους του ταξιδιού, 
-- αν έχουν ήδη γίνει κρατήσεις γι’ αυτό.
DROP TRIGGER IF EXISTS prevent_trip_update;

DELIMITER $$
CREATE TRIGGER prevent_trip_update 
BEFORE UPDATE ON trip FOR EACH ROW
BEGIN
	DECLARE valid_reservations INT;
	DECLARE trip_id INT;
	
	SET trip_id = NEW.tr_id;
	
	SELECT COUNT(res_tr_id) INTO valid_reservations
	FROM reservation
	WHERE res_tr_id = trip_id;
	
	IF (valid_reservations>0) THEN 
		IF (NEW.tr_departure <=> OLD.tr_departure) THEN
			SIGNAL SQLSTATE '99000'
			SET MESSAGE_TEXT = 'CANNOT MODIFY DEPARTURE DATE. RESERVATIONS EXIST.';
		END IF; 
		IF (NEW.tr_return <=> OLD.tr_return) THEN
			SIGNAL SQLSTATE '99001'
			SET MESSAGE_TEXT = 'CANNOT MODIFY RETURN DATE. RESERVATIONS EXIST.';
		END IF; 
		IF (NEW.tr_cost <=> OLD.tr_cost) THEN
			SIGNAL SQLSTATE '99002'
			SET MESSAGE_TEXT = 'CANNOT MODIFY TRIP COST. RESERVATIONS EXIST.';
		END IF; 
	END IF;
END$$
DELIMITER ;;

-- 3.1.4.3 
-- Trigger: 
-- Δεν επιτρέπει τη μείωση του μισθού ενός υπαλλήλου
DROP TRIGGER IF EXISTS prevent_salary_update;

DELIMITER $$
CREATE TRIGGER prevent_salary_update 
BEFORE UPDATE ON worker FOR EACH ROW
BEGIN
	IF (NEW.wrk_salary < OLD.wrk_salary) THEN
		SIGNAL SQLSTATE '88000'
		SET MESSAGE_TEXT = 'CANNOT MODIFY SALARY.';
	END IF; 
END$$
DELIMITER ;;
