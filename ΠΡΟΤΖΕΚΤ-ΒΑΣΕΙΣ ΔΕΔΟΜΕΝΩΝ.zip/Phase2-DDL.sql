CREATE TABLE it (
    it_at VARCHAR(10) PRIMARY KEY,
    it_password VARCHAR(10) NOT NULL DEFAULT 'password',
    start_date DATE NOT NULL,
    end_date DATE,
	it_logged BIT DEFAULT False
);

CREATE TABLE log (
	l_id INT AUTO_INCREMENT PRIMARY KEY,
	l_table VARCHAR(30),
	l_action VARCHAR(40),
	l_user VARCHAR(20),
	l_timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE offers (
	code INT PRIMARY KEY,
	start_date DATE NOT NULL,
	end_date DATE NOT NULL,
	cost DECIMAL(10,2),
	destination INT
);

CREATE TABLE reservation_offers (
	res_code INT PRIMARY KEY,
	lastname VARCHAR(20) NOT NULL,
	firstname VARCHAR(20) NOT NULL, 
	offer_code INT NOT NULL,
	amount DECIMAL(10,2) DEFAULT 0
);

ALTER TABLE it
ADD FOREIGN KEY (it_at) REFERENCES worker(wrk_at) ON DELETE CASCADE;

ALTER TABLE offers
ADD FOREIGN KEY (destination) REFERENCES destination(dst_id);

ALTER TABLE reservation_offers
ADD FOREIGN KEY (offer_code) REFERENCES offers(code);

CREATE INDEX idx_amount
USING BTREE
ON reservation_offers(amount);

CREATE INDEX idx_lastname
USING HASH
ON reservation_offers(lastname(20));