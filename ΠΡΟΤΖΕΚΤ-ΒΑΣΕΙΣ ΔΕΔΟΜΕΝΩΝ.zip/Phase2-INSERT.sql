INSERT INTO offers (code, start_date, end_date, cost, destination) VALUES ('1', '2023-01-15', '2023-01-31', '750', '3');
INSERT INTO offers (code, start_date, end_date, cost, destination) VALUES ('2', '2023-02-01', '2023-02-07', '600', '18');
INSERT INTO offers (code, start_date, end_date, cost, destination) VALUES ('3', '2023-02-01', '2023-02-07', '300', '11');


INSERT INTO it (it_at, it_password, start_date, end_date, it_logged) VALUES ('ΑΒ233853', 'password', '2023-02-01', NULL, b'1');