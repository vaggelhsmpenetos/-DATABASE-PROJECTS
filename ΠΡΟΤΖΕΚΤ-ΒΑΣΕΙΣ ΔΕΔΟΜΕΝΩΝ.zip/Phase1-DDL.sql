CREATE TABLE phones
(
ph_br_code int(11),
ph_number char(10),
PRIMARY KEY(ph_br_code, ph_number)
);

CREATE TABLE branch
(
br_code int(11),
br_street varchar(30),
br_num int(4),
br_city varchar(30),
PRIMARY KEY(br_code)
);

CREATE TABLE manages
(
mng_adm_AT char(10),
mng_br_code int(11),
PRIMARY KEY(mng_adm_AT, mng_br_code)
);

CREATE TABLE admin 
(
adm_AT char(10),
adm_type enum('LOGISTICS','ADMINISTRATIVE','ACCOUNTING'),
adm_diploma varchar(200),
PRIMARY KEY(adm_AT)
);

CREATE TABLE `event`
(
ev_tr_id int(11),
ev_start datetime,
ev_end datetime,
ev_descr text,
PRIMARY KEY(ev_tr_id, ev_start)
);

CREATE TABLE driver
(
drv_AT char(10),
drv_license enum('A','B','C','D'),
drv_route enum('LOCAL','ABROAD'),
drv_experience tinyint(4),
PRIMARY KEY(drv_AT)
);

CREATE TABLE worker
(
wrk_AT char(10),
wrk_name varchar(20),
wrk_lname varchar(20),
wrk_salary float(7,2),
wrk_br_code int(11),
PRIMARY KEY(wrk_AT)
);

CREATE TABLE trip
(
tr_id int(11),
tr_departure datetime,
tr_return datetime,
tr_maxseats tinyint(4),
tr_cost float(7,2),
tr_br_code int(11),
tr_gui_AT char(10),
tr_drv_AT char(10),
PRIMARY KEY(tr_id)
);

CREATE TABLE guide
(
gui_AT char(10),
gui_cv text,
PRIMARY KEY(gui_AT)
);

CREATE TABLE languages 
(
lng_gui_AT char(10),
lng_language varchar(30),
PRIMARY KEY(lng_gui_AT, lng_language)
);

CREATE TABLE travel_to
(
to_tr_id int(11),
to_dst_id int(11),
to_arrival datetime,
to_departure datetime,
PRIMARY KEY(to_tr_id, to_dst_id)
);

CREATE TABLE destination
(
dst_id int(11),
dst_name varchar(50),
dst_descr text,
dst_rtype enum('LOCAL','ABROAD'),
dst_language varchar(30),
dst_location int(11),
PRIMARY KEY(dst_id)
);

CREATE TABLE reservation
(
res_tr_id int(11),
res_seatnum tinyint(4),
res_name varchar(20),
res_lname varchar(20),
res_isadult enum('ADULT','MINOR'),
PRIMARY KEY(res_tr_id, res_seatnum)
);

ALTER TABLE trip 
	ADD FOREIGN KEY (tr_br_code) REFERENCES branch(br_code),
	ADD FOREIGN KEY (tr_gui_AT) REFERENCES guide(gui_AT) ON DELETE CASCADE,
	ADD FOREIGN KEY (tr_drv_AT) REFERENCES driver(drv_AT) ON DELETE CASCADE;

ALTER TABLE `event`
	ADD FOREIGN KEY (ev_tr_id) REFERENCES trip(tr_id);

ALTER TABLE worker
	ADD FOREIGN KEY (wrk_br_code) REFERENCES branch(br_code);

ALTER TABLE manages
	ADD FOREIGN KEY (mng_adm_AT) REFERENCES admin(adm_AT) ON DELETE CASCADE;

ALTER TABLE manages
	ADD FOREIGN KEY (mng_adm_AT) REFERENCES admin(adm_AT) ON DELETE CASCADE,
	ADD FOREIGN KEY (mng_br_code) REFERENCES branch(br_code);

ALTER TABLE admin
	ADD FOREIGN KEY (adm_AT) REFERENCES worker(wrk_AT) ON DELETE CASCADE;

ALTER TABLE languages
	ADD FOREIGN KEY (lng_gui_AT) REFERENCES guide(gui_AT) ON DELETE CASCADE;

ALTER TABLE driver
	ADD FOREIGN KEY (drv_AT) REFERENCES worker(wrk_AT) ON DELETE CASCADE;

ALTER TABLE reservation
	ADD FOREIGN KEY (res_tr_id) REFERENCES trip(tr_id);

ALTER TABLE destination
	ADD FOREIGN KEY (dst_location) REFERENCES destination(dst_id);

ALTER TABLE travel_to
	ADD FOREIGN KEY (to_dst_id) REFERENCES destination(dst_id),
	ADD FOREIGN KEY (to_tr_id) REFERENCES trip(tr_id);

ALTER TABLE phones
	ADD FOREIGN KEY (ph_br_code) REFERENCES branch(br_code);
